
import React, { useState, useEffect, useCallback } from 'react';
import { TEACHERS, LOCAL_STORAGE_KEY } from './constants';
import { Registration, TeacherStatus } from './types';
import RegistrationForm from './components/RegistrationForm';
import TeacherGrid from './components/TeacherGrid';
import RegistrationList from './components/RegistrationList';

const App: React.FC = () => {
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [activeTab, setActiveTab] = useState<'register' | 'list'>('register');
  const [notification, setNotification] = useState<{ type: 'success' | 'error', message: string } | null>(null);

  // Initialize data from local storage
  useEffect(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        setRegistrations(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse registrations", e);
      }
    }
  }, []);

  // Save to local storage whenever registrations change
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(registrations));
  }, [registrations]);

  const handleRegister = useCallback((studentName: string, studentId: string, teacherId: string) => {
    // Validation
    const teacherRegs = registrations.filter(r => r.teacherId === teacherId);
    if (teacherRegs.length >= 2) {
      setNotification({ type: 'error', message: 'Giáo viên này đã nhận đủ số lượng sinh viên.' });
      return;
    }

    const alreadyRegistered = registrations.find(r => r.studentId === studentId);
    if (alreadyRegistered) {
      setNotification({ type: 'error', message: 'Mã số sinh viên này đã đăng ký rồi.' });
      return;
    }

    const newRegistration: Registration = {
      id: Math.random().toString(36).substr(2, 9),
      studentName,
      studentId,
      teacherId,
      timestamp: Date.now(),
    };

    setRegistrations(prev => [...prev, newRegistration]);
    setNotification({ type: 'success', message: 'Đăng ký giáo viên hướng dẫn thành công!' });
    setTimeout(() => setActiveTab('list'), 1500);
  }, [registrations]);

  const handleDelete = useCallback((regId: string) => {
    if (window.confirm("Bạn có chắc chắn muốn hủy đăng ký này?")) {
      setRegistrations(prev => prev.filter(r => r.id !== regId));
      setNotification({ type: 'success', message: 'Đã hủy đăng ký thành công.' });
    }
  }, []);

  const getTeacherStatus = (): TeacherStatus[] => {
    return TEACHERS.map(t => ({
      ...t,
      currentRegistrations: registrations.filter(r => r.teacherId === t.id).length
    }));
  };

  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-indigo-700 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-3xl font-extrabold tracking-tight">Hệ Thống Đăng Ký</h1>
              <p className="mt-1 text-indigo-100 font-medium">Lựa chọn Giáo viên hướng dẫn cho Đồ án/Khóa luận</p>
            </div>
            <div className="mt-4 md:mt-0 flex space-x-2">
              <button 
                onClick={() => setActiveTab('register')}
                className={`px-4 py-2 rounded-md font-medium transition-colors ${activeTab === 'register' ? 'bg-white text-indigo-700' : 'bg-indigo-600 hover:bg-indigo-500'}`}
              >
                <i className="fas fa-edit mr-2"></i>Đăng ký
              </button>
              <button 
                onClick={() => setActiveTab('list')}
                className={`px-4 py-2 rounded-md font-medium transition-colors ${activeTab === 'list' ? 'bg-white text-indigo-700' : 'bg-indigo-600 hover:bg-indigo-500'}`}
              >
                <i className="fas fa-list-ul mr-2"></i>Danh sách
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow container mx-auto px-4 py-8">
        {/* Notification Toast */}
        {notification && (
          <div className={`fixed top-4 right-4 z-50 p-4 rounded-lg shadow-xl flex items-center space-x-3 animate-bounce ${notification.type === 'success' ? 'bg-green-100 text-green-800 border-l-4 border-green-500' : 'bg-red-100 text-red-800 border-l-4 border-red-500'}`}>
            <i className={`fas ${notification.type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}`}></i>
            <span className="font-medium">{notification.message}</span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Status Sidebar */}
          <div className="lg:col-span-1 space-y-6">
             <div className="bg-white rounded-xl shadow-md p-6 border border-slate-200">
               <h2 className="text-lg font-bold text-slate-800 mb-4 flex items-center">
                 <i className="fas fa-users-viewfinder text-indigo-600 mr-2"></i>
                 Trạng thái các slot
               </h2>
               <div className="space-y-4">
                 {getTeacherStatus().map(t => (
                   <div key={t.id} className="space-y-1">
                     <div className="flex justify-between text-sm">
                       <span className="font-semibold text-slate-700 truncate mr-2" title={t.name}>{t.name}</span>
                       <span className={`font-medium ${t.currentRegistrations >= t.maxSlots ? 'text-red-500' : 'text-green-600'}`}>
                         {t.currentRegistrations}/{t.maxSlots}
                       </span>
                     </div>
                     <div className="w-full bg-slate-100 rounded-full h-2">
                       <div 
                        className={`h-2 rounded-full transition-all duration-500 ${t.currentRegistrations >= t.maxSlots ? 'bg-red-500' : 'bg-indigo-500'}`} 
                        style={{ width: `${(t.currentRegistrations / t.maxSlots) * 100}%` }}
                       ></div>
                     </div>
                   </div>
                 ))}
               </div>
             </div>

             <div className="bg-indigo-50 rounded-xl p-6 border border-indigo-100">
               <h3 className="font-bold text-indigo-900 mb-2">Quy định đăng ký:</h3>
               <ul className="text-sm text-indigo-800 space-y-2 list-disc list-inside">
                 <li>Mỗi giảng viên chỉ nhận tối đa 02 sinh viên.</li>
                 <li>Sinh viên chỉ được đăng ký 01 giảng viên duy nhất.</li>
                 <li>Cần nhập chính xác Mã số sinh viên (MSSV).</li>
                 <li>Trong trường hợp hết chỗ, vui lòng liên hệ văn phòng khoa.</li>
               </ul>
             </div>
          </div>

          {/* Tab Content */}
          <div className="lg:col-span-2">
            {activeTab === 'register' ? (
              <div className="bg-white rounded-xl shadow-md p-8 border border-slate-200">
                <h2 className="text-2xl font-bold text-slate-800 mb-6">Thông tin đăng ký mới</h2>
                <RegistrationForm teachers={getTeacherStatus()} onSubmit={handleRegister} />
              </div>
            ) : (
              <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
                <div className="p-6 border-b border-slate-200 flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-slate-800">Danh sách đăng ký</h2>
                  <span className="bg-indigo-100 text-indigo-800 py-1 px-3 rounded-full text-sm font-bold">
                    Tổng: {registrations.length}
                  </span>
                </div>
                <RegistrationList 
                  registrations={registrations} 
                  teachers={TEACHERS} 
                  onDelete={handleDelete}
                />
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-slate-400 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-sm">© 2024 Khoa Công nghệ Thông tin - Hệ thống Đăng ký Giáo viên Hướng dẫn</p>
          <div className="mt-4 flex justify-center space-x-6">
            <a href="#" className="hover:text-white transition-colors">Hỗ trợ</a>
            <a href="#" className="hover:text-white transition-colors">Quy định</a>
            <a href="#" className="hover:text-white transition-colors">Liên hệ</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
